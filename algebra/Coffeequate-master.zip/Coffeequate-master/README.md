Coffeequate <sub><sup>v1.2.2</sup></sub>
=============================

A computer algebra system for JavaScript. Full documentation is [here](http://coffeequate.readthedocs.org).

[![Build Status](https://travis-ci.org/MatthewJA/Coffeequate.svg)](https://travis-ci.org/MatthewJA/Coffeequate)[![Documentation Status](https://readthedocs.org/projects/coffeequate/badge/?version=latest)](https://readthedocs.org/projects/coffeequate/?badge=latest)

## License
All current and previous versions licensed under the MIT License. See /LICENSE for a copy of this license.