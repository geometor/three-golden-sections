# geometry-utils
utility functions for calculating 2D geometry
