
var exports = module.exports = require("./lib/utils");
exports.Shape = require("./lib/shape");
exports.Arc = require("./lib/arc");
exports.Vector = require("./lib/vector");
exports.Point = require("./lib/vector"); // A Vector does all a Point does and more