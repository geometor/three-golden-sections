M.register("Interval", function (M, Expression, config){
	function Integer (f) {
		
	}
	// This could theoretically be used to detect asymptotes.
	
});
