M.register("Integer", function (M, Expression, config){
	function Integer (f) {
		
	}
	M.language.Number(function (str) {
		
	});
});
