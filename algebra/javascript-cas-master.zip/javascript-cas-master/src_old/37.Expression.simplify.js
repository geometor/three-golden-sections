Expression.prototype.simplify = function() {
	return this;
};