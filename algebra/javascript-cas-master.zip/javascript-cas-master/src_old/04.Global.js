
// The global object is the global context. It will have functions like sin, cos, tan, etc.

var Global = {};