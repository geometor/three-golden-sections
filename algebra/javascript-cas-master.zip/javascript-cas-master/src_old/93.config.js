//Use complex numbers by default
Expression.Numerical = Expression.Complex;
//Expression.Numerical = Expression.NumericalReal;
