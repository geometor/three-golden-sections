var M = require('../');
M.Expression.prototype.valueOf = function () {
    return null;
};